PLUGIN.name = "Posters"
PLUGIN.author = "SHOOTER#5269"
PLUGIN.description = "Adds the ability for players to place decals on walls."

-- This require the player to restart there game for these to take effect. 
game.AddDecal( "posterbreen", "decals/decal_posterbreen" )
game.AddDecal( "posterlambda", "decals/lambdaspray_1a" )