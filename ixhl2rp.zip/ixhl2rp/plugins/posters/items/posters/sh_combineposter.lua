ITEM.name = "Breen Poster"
ITEM.description = "A poster of Earth Administrator Dr.Breen."
ITEM.category = "Poster"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl"
ITEM.poster = "posterbreen"
ITEM.width = 1
ITEM.height = 1