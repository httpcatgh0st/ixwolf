ITEM.name = "Lambda Spray"
ITEM.description = "A canister of yellow spray paint.. you could do a lot with this."
ITEM.category = "Poster"
ITEM.model = "models/props_junk/popcan01a.mdl"
ITEM.skin = 2
ITEM.poster = "posterlambda"
ITEM.width = 1
ITEM.height = 1