--[[
	© 2020 TERRANOVA do not share, re-distribute or modify
	without permission of its author.
--]]

PLUGIN.name = "Union Light";
PLUGIN.description = "Adds a union light to illuminate an area.";
PLUGIN.author = "RJ";

ix.util.Include("sv_hooks.lua");