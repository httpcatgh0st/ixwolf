ATTRIBUTE.name = "Strength"
ATTRIBUTE.description = "Your ability to carry weight and manipulate heavy objects."