
ATTRIBUTE.name = "Medical Knowledge"
ATTRIBUTE.description = "Your affinity for medical items."
ATTRIBUTE.noStartBonus = true
