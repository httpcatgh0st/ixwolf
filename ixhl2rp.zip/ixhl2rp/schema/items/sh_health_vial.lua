
ITEM.name = "BioGel"
ITEM.model = Model("models/healthvial.mdl")
ITEM.description = "An vial for an auto-injector containing 10cc of field-grade chem-fluid. Incredibly strong and easy to overdose on, though its painkilling properties are second-to-none."
ITEM.category = "Medical"
ITEM.price = 40

ITEM.functions.Apply = {
	sound = "items/medshot4.wav",
	OnRun = function(itemTable)
		local client = itemTable.player

		client:SetHealth(math.min(client:Health() + 20, client:GetMaxHealth()))
	end
}
