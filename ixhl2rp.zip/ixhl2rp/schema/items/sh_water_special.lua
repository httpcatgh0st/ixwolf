
ITEM.name = "Breen's Private Reserve (Cherry)"
ITEM.model = Model("models/props_junk/popcan01a.mdl")
ITEM.skin = 1
ITEM.description = "A red aluminum can, filled with water. The steely taste from its blue counterpart seems to be absent, however.."
ITEM.category = "Consumables"

ITEM.functions.Drink = {
	OnRun = function(itemTable)
		local client = itemTable.player

		client:RestoreStamina(75)
		client:SetHealth(math.Clamp(client:Health() + 10, 0, client:GetMaxHealth()))
		client:EmitSound("npc/barnacle/barnacle_gulp2.wav", 75, 90, 0.35)
	end
}
