
ITEM.name = "Breen's Private Reserve (Lemon)"
ITEM.model = Model("models/props_junk/popcan01a.mdl")
ITEM.skin = 2
ITEM.description = "An amber aluminium can, containing artificially-flavored water with added caffeine."
ITEM.category = "Consumables"

ITEM.functions.Drink = {
	OnRun = function(itemTable)
		local client = itemTable.player

		client:RestoreStamina(50)
		client:SetHealth(math.Clamp(client:Health() + 8, 0, client:GetMaxHealth()))
		client:EmitSound("npc/barnacle/barnacle_gulp2.wav", 75, 90, 0.35)
	end
}
