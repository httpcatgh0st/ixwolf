ITEM.name = "H&K USP Match"
ITEM.description = "A reliable and accurate weapon that has a large magazine. One of the weapon's most prominent features is its large muzzle compensator that reduces muzzle climb. It has been rechambered for .45 ACP."
ITEM.model = "models/weapons/pistol/w_pistol.mdl"
ITEM.class = "tfa_rtbr_pistol"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(0.33879372477531, 270.15808105469, 0),
	fov	= 5.0470897275697,
	pos	= Vector(0, 200, -1)
}
