ITEM.name = "Overwatch Standard Issue Sniper Rifle"
ITEM.description = "A pulse rifle used by Overwatch Snipers. Identifiable by its signature blue laser sight, Overwatch Snipers use them to guard key areas. It has a slow firing rate, about once every four seconds, but incredible stopping power."
ITEM.model = "models/tnb/weapons/w_cisr.mdl"
ITEM.class = "weapon_csniper"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 5
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}