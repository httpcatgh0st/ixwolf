ITEM.name = ".357 Colt Anaconda"
ITEM.description = "A double-action revolver which fires six rounds. It is very powerful, but it has a long reload time and low rate of fire."
ITEM.model = "models/weapons/357/w_357.mdl"
ITEM.class = "tfa_rtbr_357"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(-17.581502914429, 250.7974395752, 0),
	fov	= 5.412494001838,
	pos	= Vector(57.109928131104, 181.7945098877, -60.738327026367)
}
