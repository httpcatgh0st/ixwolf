ITEM.name = "RATEL Compact Shotgun"
ITEM.description = "What appears to be a modified Heavy Shotgun turned into a compact weapon. The logo for 'RATEL' is printed on one side of the gun's slider."
ITEM.model = "models/hla/shotgun/w_shotgun.mdl"
ITEM.class = "hlashotty"
ITEM.weaponCategory = "sidearm"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}