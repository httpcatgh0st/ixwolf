ITEM.name = "H&K MP5K"
ITEM.description = "a compact, fully automatic firearm, used by both the Combine and the Resistance. It is chambered in 4.6x30mm."
ITEM.model = "models/weapons/mp5k/w_mp5k.mdl"
ITEM.class = "tfa_rtbr_smg2"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 2
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}