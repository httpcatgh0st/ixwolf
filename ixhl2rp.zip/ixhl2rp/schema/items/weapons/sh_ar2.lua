ITEM.name = "XM-29 OICW"
ITEM.description = "Essentially an AR2 'Pulse Rifle' with a scope instead of the energy ball thrower. Its recoil makes it very difficult to control past five shots in a row."
ITEM.model = "models/weapons/oicw/w_oicw.mdl"
ITEM.class = "tfa_rtbr_oicw"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 4
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),
	fov	= 12.085652091515,
	pos	= Vector(0, 200, 0)
}