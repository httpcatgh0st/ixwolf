ITEM.name = "Pheropods"
ITEM.description = "Pheropods, commonly known as Bugbait among the Resistance are glandular sacs. They are harvested from dead Antlion Guards to decieve and command Antlions."
ITEM.model = "models/weapons/w_bugbait.mdl"
ITEM.class = "weapon_bugbait"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1
ITEM.iconCam = {
	ang	= Angle(0.33879372477531, 270.15808105469, 0),
	fov	= 5.0470897275697,
	pos	= Vector(0, 200, -1)
}
