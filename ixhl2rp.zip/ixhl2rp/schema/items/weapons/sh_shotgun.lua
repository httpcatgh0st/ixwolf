ITEM.name = "Franchi SPAS-12 Pump Action"
ITEM.description = "A powerful pump-action scattergun, used by the Combine Overwatch and some Resistance members. It is very useful in close quarters combat, particularly against Headcrab Zombies and Antlions."
ITEM.model = "models/weapons/shotgun/w_shotgun.mdl"
ITEM.class = "tfa_rtbr_shotgun"
ITEM.weaponCategory = "primary"
ITEM.classes = {CLASS_EOW}
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
    pos = Vector(0, 200, 1),
    ang = Angle(0, 270, 0),
    fov = 10
}