
ITEM.name = "Metropolitan Supplements"
ITEM.model = Model("models/mres/consumables/zag_mre.mdl")
ITEM.description = "A large plastic package that almost resembles that of a pre-war microwave dinner. There is a foil tin inside containing a choice of mutton, chicken or beef stew, with rice mixed into it and a full set of plastic cutlery. A small tub of assorted nuts is provided, as well as two chalky, white caffeine pills in a plastic packet. A sealed packet of crackers is separate, with a well sized tube of chocolate paste to spread onto them."
ITEM.factions = {FACTION_MPF, FACTION_OTA}

ITEM.functions.Eat = {
	OnRun = function(itemTable)
		local client = itemTable.player

		client:RestoreStamina(100)
		client:SetHealth(math.Clamp(client:Health() + 30, 0, client:GetMaxHealth()))
		client:EmitSound("npc/antlion_grub/squashed.wav", 75, 150, 0.25)
	end,
	OnCanRun = function(itemTable)
		return itemTable.player:IsCombine()
	end
}
