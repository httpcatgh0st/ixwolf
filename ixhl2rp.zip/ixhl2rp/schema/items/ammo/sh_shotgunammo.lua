ITEM.name = "12 Gauge Shells"
ITEM.useSound = "items/ammopickup.wav"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "buckshot" -- type of the ammo
ITEM.ammoAmount = 12 -- amount of the ammo
ITEM.description = "A box of shotgun shells, with glowing rings around the rims."
