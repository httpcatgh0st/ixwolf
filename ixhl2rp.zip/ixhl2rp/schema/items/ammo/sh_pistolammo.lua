ITEM.name = ".45 ACP Rounds"
ITEM.model = "models/Items/BoxSRounds.mdl"
ITEM.ammo = "pistol" -- type of the ammo
ITEM.useSound = "items/ammopickup.wav"
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A box of rimless straight-walled handgun cartridges designed by John Moses Browning in 1904, for use in his prototype Colt semi-automatic pistol."
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
