ITEM.name = "5.56mm NATO Rounds"
ITEM.model = "models/Items/BoxMRounds.mdl"
ITEM.ammo = "ar2" -- type of the ammo
ITEM.ammoAmount = 30 -- amount of the ammo
ITEM.description = "A box of rimless bottlenecked intermediate cartridges- developed in the late 1970s in Belgium by FN Herstal. It consists of the SS109, L110, and SS111 cartridges."
ITEM.classes = {CLASS_EOW}
