ITEM.name = "Bundle of Rebar"
ITEM.model = "models/Items/CrossbowRounds.mdl"
ITEM.ammo = "XBowBolt" -- type of the ammo
ITEM.ammoAmount = 6 -- amount of the ammo
ITEM.description = "Pieces of red-hot steel rebar about 12 inches (30 centimeters) long."
