ITEM.name = "4.6x30mm Case"
ITEM.model = "models/Items/BoxMRounds.mdl"
ITEM.useSound = "items/ammopickup.wav"
ITEM.ammo = "smg1" -- type of the ammo
ITEM.ammoAmount = 45 -- amount of the ammo
ITEM.description = "A small-caliber, high-velocity, smokeless powder, rebated rim, bottlenecked centerfire cartridge designed for personal defense weapons (PDW) developed by German armament manufacturer Heckler & Koch (HK) in 1999."
ITEM.classes = {CLASS_EMP, CLASS_EOW}
ITEM.flag = "V"
