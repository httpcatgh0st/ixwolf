
ITEM.name = "Medic Uniform"
ITEM.description = "A resistance uniform with medical insignia on the sleeve."
ITEM.category = "Clothing"
ITEM.flag = "v"

ITEM.replacements = {
	{"group01", "group03m"},
	{"group02", "group03m"},
	{"group03", "group03m"},
}
